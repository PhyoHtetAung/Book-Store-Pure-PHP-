<?php
   include('admin/confs/config.php');
   $id = $_GET['id'];
   $sql = "SELECT books.*, categories.name FROM books LEFT JOIN categories ON books.category_id = categories.id WHERE books.id = $id";
   $result = mysqli_query($conn, $sql);
   $row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Book Detail</title>
      <link rel="stylesheet" href="css/style.css">
   </head>
   <body>
      <h1>Book Detail</h1>
      <div class="detail">  
         <a href="index.php" class="back">&laquo; Go Back</a>  
         <img src="admin/covers/<?php echo $row['cover'] ?>"  width="150px" height="150px">  
         <h2><?php echo $row['title'] ?></h2>  
         <i>by <?php echo $row['author'] ?></i>,  <b>$<?php echo $row['price'] ?></b>  
         <p><?php echo $row['summary'] ?></p>
         <a href="add-to-cart.php?id=<?php echo $id ?>" class="add-to-cart">    Add to Cart  </a>
      </div>

   </body>
</html>
