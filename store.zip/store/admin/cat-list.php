<!DOCTYPE html>
<?php
   include("confs/auth.php");
   include('confs/config.php');
   $sql = "SELECT * FROM categories";
   $result = mysqli_query($conn, $sql);
?>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Category List</title>
      <style media="screen">
         li {
            font-size: 17px;
            margin-top: 8px;
         }
      </style>
      <link rel="stylesheet" href="css/style.css">
   </head>
   <body>
      <h1>Category List</h1>
      <ul class="menu">  
         <li><a href="book-list.php">Manage Books</a></li>  
         <li><a href="cat-list.php">Manage Categories</a></li>  
         <li><a href="logout.php">Logout</a></li>
      </ul>
      <ul>
         <?php while($row = mysqli_fetch_assoc($result)): ?>
            <li title="<?= $row['remark'] ?>">
               <a href="cat-edit.php?id=<?= $row['id'] ?>">[Edit]</a>
               <a href="cat-del.php?id=<?= $row['id'] ?>">[Del]</a>
               <?= $row['name'] ?>
            </li>
         <?php endwhile; ?>
      </ul>
      <a href="cat-new.php" class="new">New Category</a>
   </body>
</html>
