<?php include("confs/auth.php") ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>New Category</title>
      <style media="screen">
         form label {
            display: block;
            margin-top: 8px;
         }
      </style>
      <link rel="stylesheet" href="css/style.css">
   </head>
   <body>
      <h1>New Category</h1>
      <ul class="menu">  
         <li><a href="book-list.php">Manage Books</a></li>  
         <li><a href="cat-list.php">Manage Categories</a></li>   
         <li><a href="logout.php">Logout</a></li>
      </ul>
      <form action="cat-add.php" method="post">
         <label for="name">Category Name</label>
         <input type="text" name="name">
         <label for="remark">Remark</label>
         <textarea name="remark" rows="8" cols="80"></textarea> <br><br>   
         <input type="submit" name="submit" value="Add Category">
      </form>
   </body>
</html>
