<!DOCTYPE html>
<?php
   include("confs/auth.php");
   include('confs/config.php');
   $id = $_GET['id'];
   $sql = "SELECT * FROM categories WHERE id = $id";
   $result = mysqli_query($conn, $sql);
   $row = mysqli_fetch_assoc($result);
?>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Edit Category</title>
      <link rel="stylesheet" href="css/style.css">
   </head>
   <body>
      <h1>Edit Category</h1>
      <ul class="menu">  
         <li><a href="book-list.php">Manage Books</a></li>  
         <li><a href="cat-list.php">Manage Categories</a></li>  
         <li><a href="logout.php">Logout</a></li>
      </ul>
      <form action="cat-update.php" method="post">
         <input type="hidden" name="id" value="<?= $row['id'] ?>">
         <label for="name">Category Name</label>
         <input type="text" name="name" value="<?= $row['name'] ?>">
         <label for="remark">Remark</label>
         <textarea name="remark" rows="8" cols="80"><?= $row['remark'] ?></textarea> <br><br>
         <input type="submit" name="submit" value="Update Category">
      </form>
   </body>
</html>
