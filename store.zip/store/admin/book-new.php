<!DOCTYPE html>
<?php
   include("confs/auth.php");
   include('confs/config.php');
   $sql = "SELECT id, name FROM categories";
   $result = mysqli_query($conn, $sql);
?>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>New Book</title>
      <style media="screen">
         form label {
            display: block;
            margin-top: 8px;
         }
      </style>
      <link rel="stylesheet" href="css/style.css">
   </head>
   <body>
      <h1>New Book</h1>
      <ul class="menu">  
         <li><a href="book-list.php">Manage Books</a></li>  
         <li><a href="cat-list.php">Manage Categories</a></li>   
         <li><a href="logout.php">Logout</a></li>
      </ul>
      <form action="book-add.php" method="post" enctype="multipart/form-data">
         <label for="title">Title</label>
         <input type="text" name="title">
         <label for="author">Author</label>
         <input type="text" name="author">
         <label for="summary">Summary</label>
         <textarea name="summary" rows="8" cols="80"></textarea>
         <label for="pirce">Price</label>
         <input type="text" name="price">
         <label for="category_id">Category</label>
         <select name="category_id">
            <option value="0">-- Choose --</option>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
               <option value="<?= $row['id'] ?>">
                  <?= $row['name'] ?>
               </option>
            <?php endwhile; ?>
         </select>
         <label for="cover">Cover</label>
         <input type="file" name="cover"> <br><br>
         <input type="submit" name="submit" value="Add Book">
      </form>
   </body>
</html>
