<?php
   include('confs/auth.php');
   include('confs/config.php');
   $id = $_GET['id'];
   $sql = "SELECT * FROM books WHERE id = $id";
   $result = mysqli_query($conn, $sql);
   $row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Edit Book</title>
      <style media="screen">
         form label {
            display: block;
            margin-top: 8px;
         }
      </style>
      <link rel="stylesheet" href="css/style.css">
   </head>
   <body>
      <ul class="menu">  
         <li><a href="book-list.php">Manage Books</a></li>  
         <li><a href="cat-list.php">Manage Categories</a></li>  
         <li><a href="logout.php">Logout</a></li>
      </ul>
      <h1>Edit Book</h1>
      <form action="book-update.php" method="post" enctype="multipart/form-data">
         <input type="hidden" name="id" value="<?= $row['id'] ?>">
         <label for="title">Title</label>
         <input type="text" name="title" value="<?= $row['title'] ?>">
         <label for="author">Author</label>
         <input type="text" name="author" value="<?= $row['author'] ?>">
         <label for="summary">Summary</label>
         <textarea name="summary" rows="8" cols="80"><?= $row['summary'] ?></textarea>
         <label for="price">Price</label>
         <input type="text" name="price" value="<?= $row['price'] ?>">
         <label for="category_id">Category</label>
         <select name="category_id">
            <option value="0">-- Choose --</option>
            <?php
               $cat_sql = "SELECT id, name FROM categories";
               $cat_result = mysqli_query($conn, $cat_sql);
               while($cat_row = mysqli_fetch_assoc($cat_result)):
            ?>
               <option value="<?= $cat_row['id'] ?>" <?php if($cat_row['id'] == $id) echo "selected" ?>>
                  <?= $cat_row['name'] ?>
               </option>
            <?php endwhile; ?>
         </select> <br><br>
         <img src="covers/<?= $row['cover'] ?>" alt="" height="150">
         <label for="cover">Change Cover</label>
         <input type="file" name="cover"> <br><br>
         <input type="submit" name="submit" value="Update Book">
      </form>
   </body>
</html>
