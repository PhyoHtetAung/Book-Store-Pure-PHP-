<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <title>Book List</title>
      <link rel="stylesheet" href="css/style.css">
   </head>
   <body>
      <h1>Book List</h1>
      <?php
         include("confs/auth.php");
         include('confs/config.php');
         $sql = "SELECT books.*, categories.name FROM books LEFT JOIN categories ON books.category_id = categories.id";
         $result = mysqli_query($conn, $sql);
      ?>
      <ul class="menu">  
         <li><a href="book-list.php">Manage Books</a></li>  
         <li><a href="cat-list.php">Manage Categories</a></li>  
         <li><a href="logout.php">Logout</a></li>
      </ul>
      <ul class="books">
         <?php while($row = mysqli_fetch_assoc($result)): ?>
            <li style="list-style: none;">
               <img src="covers/<?php echo $row['cover'] ?>" width="140" height="140">
               <br><br>
            </li>
            <li>    
               <b><?php echo $row['title'] ?></b>      
               <i>by <?php echo $row['author'] ?></i>      
               <small>(in <?php echo $row['name'] ?>)</small>      
               <span>$<?php echo $row['price'] ?></span>      
               <div><?php echo $row['summary'] ?></div>
               [<a href="book-del.php?id=<?php echo $row['id'] ?>" class="del">del</a>]      
               [<a href="book-edit.php?id=<?php echo $row['id'] ?>">edit</a>]<br><br> 
            </li>
         <?php endwhile; ?>
      </ul>
      <a href="book-new.php" class="new">New Book</a>
   </body>
</html>
